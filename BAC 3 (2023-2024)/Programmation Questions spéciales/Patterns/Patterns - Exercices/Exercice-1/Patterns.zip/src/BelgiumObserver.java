public class BelgiumObserver implements Observer {

        private int nbrBelgium = 0;

        @Override
        public void processLine(String line) {
            if (line.contains("Belgique")) {
                nbrBelgium++;
            }
        }

        @Override
        public void printResult() {
            System.out.println("Il y avait " + nbrBelgium + " belgium.");
        }
}

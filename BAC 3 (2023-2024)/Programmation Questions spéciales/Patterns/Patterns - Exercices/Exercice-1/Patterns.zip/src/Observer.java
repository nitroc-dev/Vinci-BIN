public interface Observer {

    void processLine(String line);

    void printResult();
}

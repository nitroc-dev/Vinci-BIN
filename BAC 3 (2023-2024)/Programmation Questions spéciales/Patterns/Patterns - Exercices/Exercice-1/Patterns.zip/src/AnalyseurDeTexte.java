import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AnalyseurDeTexte {

	private static List<Observer> observers = new ArrayList<>();

	private static void registerObserver(Observer observer) {
		observers.add(observer);
	}

	private void unregisterObserver(Observer observer) {
		observers.remove(observer);
	}

	private static void notifyObservers(String line) {
		for (Observer observer : observers) {
			observer.processLine(line);
		}
	}

	private static void notifyObservers() {
		for (Observer observer : observers) {
			observer.printResult();
		}
	}

	public static void main(String[] args) throws IOException {
		BufferedReader lecteurAvecBuffer = null;
		String ligne;
		int nbrMots = 0, nbrLignes = 0, nbrPalindromes = 0, nbrBelgique = 0;
		try {
			lecteurAvecBuffer = new BufferedReader(new FileReader(args[0]));
		} catch (FileNotFoundException e) {
			System.out.println("Erreur d'ouverture");
		}

		Observer wordsObserver = new WordsObserver();
		Observer linesObserver = new LinesObserver();
		Observer palindromeObserver = new PalindromeObserver();
		Observer belgiumObserver = new BelgiumObserver();

		registerObserver(wordsObserver);
		registerObserver(linesObserver);
		registerObserver(palindromeObserver);
		registerObserver(belgiumObserver);

		while ((ligne = lecteurAvecBuffer.readLine()) != null) {
			notifyObservers(ligne);
		}

		lecteurAvecBuffer.close();

		notifyObservers();
	}
}

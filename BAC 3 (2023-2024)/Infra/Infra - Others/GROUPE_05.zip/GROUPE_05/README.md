# Sample Node.js application

This repository is a sample Node.js application for Docker's documentation.

# Run into docker container

## Build image

```bash
docker build -t node-app .
```

## Run container

```bash
docker run -p 3000:3000 -d node-app
```

## Test

```bash
curl -i localhost:3000
```

## Stop container

```bash
docker stop <container_id>
```